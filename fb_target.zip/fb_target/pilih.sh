echo ""
read -p " menu : " menu
