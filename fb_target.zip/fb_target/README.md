# FB-TARGET

Hack/Crack Your Target Facebook Account With This tool.
Easily 

### ScreenShot

<img src="https://raw.githubusercontent.com/nfs-tech-bd/FB-TARGET/main/PicsArt_04-25-09.18.28.jpg">

### Termux Commands


* `apt update`

* `apt upgrade`

* `pkg install python`

* `pkg install python2`

* `pip install mechanize`

* `pkg install git`

* `git clone http://github.com/nfs-tech-bd/FB-TARGET`

* `cd FB-TARGET`

* `python2 FB-TARGET.py`

### For Wordlist Making Tool

<a href="http://github.com/nfs-tech-bd/WORDLIST">NFS-TECH-BD Wordlist Tool</a>
